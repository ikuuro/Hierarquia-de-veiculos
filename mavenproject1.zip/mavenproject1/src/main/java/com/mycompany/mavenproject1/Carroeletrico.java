/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author ikaro
 */
                           //herança
public class Carroeletrico extends Carro {
    public double capacidadeBateria;
    
//cosntrutor
    public Carroeletrico(String marcaInformada, String modeloInformado) {
       super(marcaInformada, modeloInformado);
    }
    //metodos
    
    public void carregarBateria(){
        System.out.println("Carregando bateria");
    }
    @Override
    public void acelerar(){
        System.out.println("Acelerando carro eletrico");
    }
    
    
    
    
}
