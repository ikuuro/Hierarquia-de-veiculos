/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author ikaro
 */                //herança
public class Carro extends Mavenproject1 {
    public String marca;
    public String modelo;
    public String tipoDeCombustivel;
    public int ano;
   
    
    
    //construtores
    public Carro(String marcaInformada,String modeloInformado){
        this.marca = marcaInformada;
        this.modelo = modeloInformado;
        
    }
    public Carro (int anoInformado){
        this.ano = anoInformado;
    }
    
    
    
    
    //metodos
    public void acelerar(){
        System.out.println("Acelerando carro");
    }
    public void frear(){
        System.out.println("Freando");
    }
    
}
