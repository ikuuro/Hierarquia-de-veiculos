/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author ikaro
 */
public class Mavenproject1 {

    public static void main(String[] args) {
        //instancias
        Carro c1 = new Carro("chevrolet","onix");
        c1.ano = 2006;
        c1.tipoDeCombustivel = "etanol";
        c1.acelerar();
        c1.frear();
        
        Carroeletrico ce1 = new Carroeletrico("BYD","Dolphin");
        ce1.capacidadeBateria = 60.45;
        ce1.carregarBateria();
        ce1.acelerar();
    }

        
    
}
